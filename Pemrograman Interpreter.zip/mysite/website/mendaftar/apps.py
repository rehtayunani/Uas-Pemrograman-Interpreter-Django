from django.apps import AppConfig


class MendaftarConfig(AppConfig):
    name = 'mendaftar'
