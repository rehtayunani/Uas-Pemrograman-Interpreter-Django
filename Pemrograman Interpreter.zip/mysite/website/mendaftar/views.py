from django.shortcuts import render
from mendaftar.models import *
