from django.contrib import admin
from mendaftar.models import *

admin.site.register(Event)
admin.site.register(Visitor)

# Register your models here.
