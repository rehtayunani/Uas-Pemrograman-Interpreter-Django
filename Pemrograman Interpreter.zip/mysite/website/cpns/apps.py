from django.apps import AppConfig


class CpnsConfig(AppConfig):
    name = 'cpns'
