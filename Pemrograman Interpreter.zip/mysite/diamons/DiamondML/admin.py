from django.contrib import admin
from DiamondML.models import *

admin.site.register(harga)
# Register your models here.
