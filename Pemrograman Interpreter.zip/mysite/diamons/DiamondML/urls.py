from django.views.generic import ListView, DetailView
from django.conf.urls import url
from django.contrib import admin
from . import views
from DiamondML.models import*

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^pembelian/$', ListView.as_view(queryset=harga.objects.all(), template_name="ml/basing.html")),
    url(r'^beli/$',ListView.as_view(queryset=harga.objects.all(), template_name="ml/form.html")),
    url(r'^about/$', views.about, name='about'),
    url(r'^help/$', views.help, name='help'),
    url(r'^submit/$', views.submit, name='submit'),
]
