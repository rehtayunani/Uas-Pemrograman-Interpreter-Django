from django.apps import AppConfig


class DiamondmlConfig(AppConfig):
    name = 'DiamondML'
