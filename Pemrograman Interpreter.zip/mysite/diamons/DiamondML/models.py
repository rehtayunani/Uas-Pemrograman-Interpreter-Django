from django.db import models

class harga(models.Model):
    jumlahdiamon = models.CharField(max_length=20)
    harga = models.CharField(max_length=20)

    def __unicode__(self):
        return self.jumlahdiamond
# Create your models here.
