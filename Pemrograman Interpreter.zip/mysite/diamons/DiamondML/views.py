from django.shortcuts import render

def index(request):
	return render(request, 'ml/aku.html')

def about(request):
	return render(request, 'ml/about.html')

def help(request):
	return render(request, 'ml/help.html')
	
def submit(request):
	return render(request, 'ml/submit.html')